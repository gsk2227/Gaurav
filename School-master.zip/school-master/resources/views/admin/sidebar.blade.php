


             <ul class="nav nav-pills nav-stacked demo">

              <li>{{ HTML::link('/addnews', 'Add News', true)}}</li>

              <li>{{ HTML::link('/maintainnews', 'Maintain News', true)}}</li>

              <li>{{ HTML::link('/addnotice', 'Add Notice', true)}}</li>

              <li>{{ HTML::link('', 'Maintain Notice', true)}}</li>

              <li>{{ HTML::link('', 'Add Events', true)}}</li>

              <li>{{ HTML::link('', 'Maintain Events', true)}}</li>

            </ul>

        


          