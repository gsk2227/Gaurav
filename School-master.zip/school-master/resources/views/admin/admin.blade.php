
  @include('admin.header') 
  
      <div class="row">

          <div class="col-md-2 navigation ">

            @include('admin.sidebar') 

          </div>

          <div class="col-md-10">

           @include('admin.main') 

          </div>

      </div>

    </div>
   
  </body>

</html>