<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notice2 extends Model
{
    //
}
